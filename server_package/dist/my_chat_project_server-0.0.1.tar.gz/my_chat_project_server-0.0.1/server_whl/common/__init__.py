def logger():
    return None


def log():
    return None